# Nexora RP — Đăng nhập tài khoản riêng

## Chạy trên Windows
1. Mở thư mục `nexora-rp-no-native` trong VS Code.
2. Mở Terminal, chạy `npm.cmd install`.
3. Sao chép `.env.example` thành `.env`, sửa `SESSION_SECRET` thành chuỗi ngẫu nhiên dài ít nhất 32 ký tự. Nếu cổng 3000 bị chiếm, đổi `PORT` và `BASE_URL` cùng lúc.
4. Chạy `npm.cmd start`, mở `http://localhost:3000` (hoặc cổng đã cấu hình).
5. Người chơi nhấn **ĐĂNG NHẬP → ĐĂNG KÝ** để tạo tài khoản. Tên đăng nhập 3–24 ký tự chữ/số/gạch dưới; mật khẩu ít nhất 10 ký tự.

## Cấp quyền Admin đầu tiên (thực hiện trên máy chủ)
1. Đăng ký một tài khoản của riêng bạn trên website.
2. Dừng server bằng Ctrl+C.
3. Mở terminal tại thư mục dự án và chạy (thay `TEN_ADMIN` bằng tên vừa đăng ký):

```powershell
node --input-type=module -e "import {DatabaseSync} from 'node:sqlite'; const db=new DatabaseSync('./data/nexora.db'); const r=db.prepare('UPDATE users SET is_admin=1 WHERE username=? COLLATE NOCASE').run('TEN_ADMIN'); console.log('So tai khoan duoc cap quyen:',r.changes); db.close();"
```

4. Khởi động lại bằng `npm.cmd start`, đăng xuất rồi đăng nhập lại. Mục **QUẢN TRỊ** xuất hiện, có thể thêm/sửa/xóa nội dung và khóa/mở khóa người dùng.

## Dữ liệu và bảo mật
- SQLite ở `data/nexora.db`, giữ file này khi nâng cấp để không mất nội dung và tài khoản.
- Mật khẩu được băm bằng `scrypt` kèm salt ngẫu nhiên, không lưu mật khẩu gốc.
- Không chia sẻ `.env`, `data/nexora.db` hoặc mật khẩu. Sao lưu trước khi nâng cấp.
- Website giữ nguyên các trang, logo, video, Discord cộng đồng và link tải launcher. Discord chỉ còn là link cộng đồng, không dùng để đăng nhập.
- Đây là bản chạy thử. Trước khi triển khai công khai cần HTTPS, persistent session store, chống brute force mạnh hơn, chính sách khôi phục mật khẩu và rà soát bảo mật.


## Xác thực email và quên mật khẩu
Cài đặt `npm.cmd install`, sao chép `.env.example` thành `.env`, cấu hình `SESSION_SECRET` và SMTP_HOST/PORT/USER/PASS/FROM. Với Gmail, dùng App Password của tài khoản email (không dùng mật khẩu đăng nhập Gmail). Không đưa `.env` lên GitHub.

Người chơi đăng ký → nhập thông tin → nhận mã 6 chữ số qua email → nhập mã trong 10 phút. Quên mật khẩu → gửi mã qua email đã đăng ký → nhập mã và mật khẩu mới. Giới hạn 5 lần nhập mã, rate limit chung `/auth` là 20 yêu cầu/15 phút/IP. Nếu SMTP chưa cấu hình, website thông báo lỗi thay vì giả vờ gửi mã.

Lưu ý: trang chính sách quyền riêng tư hiện chỉ là lời nhắc; hãy xuất bản chính sách thực tế trước khi triển khai công khai. Các tài khoản cũ chưa có email phải được quản trị viên hỗ trợ liên kết email trước khi dùng tính năng quên mật khẩu. Với production, cần session store bền vững thay vì MemoryStore mặc định.


## Bản LOW-RAM
- Đã thay `express-session` MemoryStore bằng signed cookie session để không giữ session của người dùng trong RAM server.
- SQLite chuyển từ WAL sang journal DELETE và giới hạn page cache khoảng 2 MB.
- JSON request giảm xuống 2 MB.
- Start command giới hạn V8 heap 128 MB + semi-space 2 MB để tránh Node tự mở rộng RAM quá mức trên gói hosting nhỏ.
- Nếu hosting có giới hạn dưới khoảng 256 MB, không nên chạy thêm process Node khác trong cùng project.
