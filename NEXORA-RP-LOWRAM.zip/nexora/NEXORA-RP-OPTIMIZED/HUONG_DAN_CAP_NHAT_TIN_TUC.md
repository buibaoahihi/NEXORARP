# Cập nhật chức năng ảnh cho Tin tức

- Trong Quản trị > Loại nội dung > Tin tức, chọn ảnh tại mục Ảnh bài viết. Có xem trước ảnh trước khi lưu.
- Hỗ trợ PNG, JPG/JPEG, WEBP, GIF; tối đa 5 MB mỗi ảnh.
- Ảnh được lưu trong thư mục `uploads/`, đường dẫn ảnh được lưu cùng bài viết trong SQLite.
- Khi sửa bài viết, ảnh cũ được giữ nguyên nếu không chọn ảnh mới; đánh dấu “Xóa ảnh hiện tại khi lưu” để gỡ ảnh.
- Bài tin tức có ảnh sẽ hiển thị ảnh ở trang Tin tức và Tin tức mới nhất trên trang chủ.

## Chạy dự án

1. Cài Node.js phiên bản 22.13 trở lên.
2. Mở terminal tại thư mục dự án và chạy `npm install`.
3. Cấu hình `.env` theo `.env.example` (nếu cần SMTP/SESSION_SECRET).
4. Chạy `npm start`, sau đó mở `http://localhost:3000`.

Cơ sở dữ liệu cũ được tự động bổ sung cột `image_url` khi khởi động; không cần xóa dữ liệu hiện có.
