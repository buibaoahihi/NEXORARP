import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { DatabaseSync } from 'node:sqlite';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import nodemailer from 'nodemailer';

const root = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const dbDir = path.join(root, 'data');
fs.mkdirSync(dbDir, { recursive: true });
const db = new DatabaseSync(path.join(dbDir, 'nexora.db'));
db.exec('PRAGMA journal_mode = DELETE; PRAGMA synchronous = NORMAL; PRAGMA temp_store = FILE; PRAGMA cache_size = -2048;');
const uploadDir = path.join(root, 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
db.exec(`
  CREATE TABLE IF NOT EXISTS content (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL CHECK(type IN ('rules','news','media')),
    title TEXT NOT NULL,
    body TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL DEFAULT '',
    youtube_id TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);
try { db.exec('ALTER TABLE content ADD COLUMN image_url TEXT NOT NULL DEFAULT \'\''); } catch (e) { if (!String(e.message).includes('duplicate column')) throw e; }
const count = db.prepare('SELECT COUNT(*) AS n FROM content').get().n;
if (!count) {
  const add = db.prepare('INSERT INTO content(type,title,body,category,youtube_id) VALUES(?,?,?,?,?)');
  add.run('rules','Quy tắc Roleplay cơ bản','Tôn trọng người chơi khác, không phá trải nghiệm Roleplay. Đây là luật mẫu; quản trị viên có thể thay thế.','Quy định chung','');
  add.run('rules','Không sử dụng thông tin ngoài nhân vật','Không dùng thông tin từ Discord, livestream hoặc ngoài game để tạo lợi thế cho nhân vật.','Roleplay','');
  add.run('news','Chào mừng đến với Nexora RP','Website chính thức của Nexora RP đã sẵn sàng. Theo dõi tại đây để cập nhật tin tức và sự kiện.','Thông báo','');
}
const isProduction = process.env.NODE_ENV === 'production';
if (isProduction && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) throw Error('Set SESSION_SECRET at least 32 chars');
app.set('trust proxy', isProduction ? 1 : false);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({limit:'2mb', strict:true}));

// Lightweight signed-cookie session: avoids express-session's in-memory store,
// which can grow with every logged-in visitor and is unsuitable for small RAM hosting.
const SESSION_COOKIE = 'nexora.sid';
const SESSION_TTL = 1000 * 60 * 60 * 8;
const sessionSecret = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
function b64url(v){return Buffer.from(v).toString('base64url');}
function readCookie(header,name){for(const part of String(header||'').split(';')){const i=part.indexOf('=');if(i<0)continue;const k=part.slice(0,i).trim();if(k===name)return decodeURIComponent(part.slice(i+1).trim());}return '';}
function signSession(payload){return crypto.createHmac('sha256',sessionSecret).update(payload).digest('base64url');}
function setSessionCookie(res,data){const payload=b64url(JSON.stringify({v:1,exp:Date.now()+SESSION_TTL,...data}));const value=payload+'.'+signSession(payload);const secure=isProduction?' Secure':'';res.setHeader('Set-Cookie',`${SESSION_COOKIE}=${encodeURIComponent(value)}; Path=/; Max-Age=${Math.floor(SESSION_TTL/1000)}; HttpOnly; SameSite=Lax;${secure}`);}
function clearSessionCookie(res){res.setHeader('Set-Cookie',`${SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax${isProduction?'; Secure':''}`);}
app.use((req,res,next)=>{
  const raw=readCookie(req.headers.cookie,SESSION_COOKIE); let data=null;
  if(raw){try{const [payload,sig]=raw.split('.');const expected=signSession(payload);if(payload&&sig&&sig.length===expected.length&&crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected))){const parsed=JSON.parse(Buffer.from(payload,'base64url').toString('utf8'));if(parsed.exp>Date.now())data=parsed;}}catch{}}
  req.session={user:data?.user||null,csrf:data?.csrf||null,regenerate(cb){this.user=null;this.csrf=crypto.randomBytes(24).toString('hex');this._new=true;cb();},destroy(cb){this.user=null;this.csrf=null;this._destroyed=true;cb();}};
  req.saveSession=()=>setSessionCookie(res,{user:req.session.user,csrf:req.session.csrf});
  req.clearSession=()=>clearSessionCookie(res);
  next();
});
app.use('/api',rateLimit({windowMs:15*60*1000,limit:150,standardHeaders:'draft-7',legacyHeaders:false}));
app.use('/auth',rateLimit({windowMs:15*60*1000,limit:20,standardHeaders:'draft-7',legacyHeaders:false}));
app.use('/uploads', express.static(uploadDir, { fallthrough: false, maxAge: '30d', immutable: true }));
app.use(express.static(path.join(root,'public'), { maxAge: isProduction ? '1d' : 0, etag: true }));
const safeLink = (raw, fallback) => {try {const u = new URL(raw);return u.protocol === 'https:' || (u.protocol === 'http:' && !isProduction) ? u.href : fallback;} catch {return fallback;}};
db.exec(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL, salt TEXT NOT NULL, is_admin INTEGER NOT NULL DEFAULT 0, is_locked INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);`);
db.exec(`CREATE TABLE IF NOT EXISTS verification_codes (email TEXT NOT NULL, purpose TEXT NOT NULL, username TEXT, password_hash TEXT, salt TEXT, birth_date TEXT, code_hash TEXT NOT NULL, expires_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(email,purpose));`);
for (const col of ['email TEXT','birth_date TEXT']) {try {db.exec(`ALTER TABLE users ADD COLUMN ${col}`);}catch(e){if(!String(e.message).includes('duplicate column'))throw e;}}
db.exec('CREATE UNIQUE INDEX IF NOT EXISTS users_email_unique ON users(email) WHERE email IS NOT NULL');
const smtpReady=()=>!!(process.env.SMTP_HOST&&process.env.SMTP_USER&&process.env.SMTP_PASS&&process.env.SMTP_FROM);
const mailer=()=>nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:Number(process.env.SMTP_PORT||587)===465,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}});
const codeHash=(email,purpose,code)=>crypto.createHmac('sha256',process.env.SESSION_SECRET||'local-dev-only').update(email+'|'+purpose+'|'+code).digest('hex');
const validEmail=e=>typeof e==='string'&&e.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
const validBirth=d=>typeof d==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&!Number.isNaN(Date.parse(d))&&new Date(d+'T00:00:00Z')<=new Date();
async function sendCode(email,purpose,username='',password='',birthDate='') {
 if(!smtpReady())throw Error('Máy chủ chưa cấu hình SMTP để gửi mã qua email.');
 const code=String(crypto.randomInt(100000,1000000));const salt=purpose==='register'?crypto.randomBytes(24).toString('hex'):null;
 const hash=purpose==='register'?hashPassword(password,salt):null;
 // Never store or log the raw OTP or raw password.
 db.prepare('INSERT INTO verification_codes(email,purpose,username,password_hash,salt,birth_date,code_hash,expires_at,attempts) VALUES(?,?,?,?,?,?,?,?,0) ON CONFLICT(email,purpose) DO UPDATE SET username=excluded.username,password_hash=excluded.password_hash,salt=excluded.salt,birth_date=excluded.birth_date,code_hash=excluded.code_hash,expires_at=excluded.expires_at,attempts=0').run(email,purpose,username,hash,salt,birthDate,codeHash(email,purpose,code),Date.now()+10*60*1000);
 try {await mailer().sendMail({from:process.env.SMTP_FROM,to:email,subject:purpose==='register'?'Nexora RP - Xác thực đăng ký':'Nexora RP - Đặt lại mật khẩu',text:`Mã xác thực Nexora RP của bạn: ${code}\nMã hết hạn sau 10 phút. Nếu bạn không yêu cầu, hãy bỏ qua email này.`});}
 catch(e){db.prepare('DELETE FROM verification_codes WHERE email=? AND purpose=?').run(email,purpose);console.error('SMTP send failed:',e.message);throw Error('Không gửi được email. Kiểm tra cấu hình SMTP.');}
}
function verifyCode(email,purpose,code){const row=db.prepare('SELECT * FROM verification_codes WHERE email=? AND purpose=?').get(email,purpose);if(!row||row.expires_at<Date.now()||row.attempts>=5||!/^\d{6}$/.test(String(code)))return null;db.prepare('UPDATE verification_codes SET attempts=attempts+1 WHERE email=? AND purpose=?').run(email,purpose);if(!crypto.timingSafeEqual(Buffer.from(row.code_hash,'hex'),Buffer.from(codeHash(email,purpose,String(code)),'hex')))return null;return row;}
const getUser=db.prepare('SELECT * FROM users WHERE id=?');
const getByName=db.prepare('SELECT * FROM users WHERE username=? COLLATE NOCASE');
const publicUser=u=>({id:u.id,username:u.username});
const buibaoahihi=req=>{const u=req.session.user&&getUser.get(req.session.user.id);return !!u&&!u.is_locked&&!!u.is_admin;};
const hashPassword=(password,salt)=>crypto.scryptSync(password,salt,64).toString('hex');
function validPassword(p){return typeof p==='string'&&p.length>=10&&p.length<=128;}
function validName(n){return typeof n==='string'&&/^[a-zA-Z0-9_]{3,24}$/.test(n);}
function logIn(req,res,u){req.session.regenerate(err=>{if(err)return res.status(500).json({error:'Không thể tạo phiên đăng nhập'});req.session.user=publicUser(u);req.session.csrf=crypto.randomBytes(24).toString('hex');req.saveSession();res.json({ok:true});});}
app.get('/api/config',(req,res)=>res.json({discord:safeLink(process.env.DISCORD_INVITE_URL,'https://discord.com/'),download:safeLink(process.env.DOWNLOAD_URL,'https://fivem.net/')}));
app.get('/api/me',(req,res)=>{const u=req.session.user&&getUser.get(req.session.user.id);const valid=u&&!u.is_locked;res.json({user:valid?publicUser(u):null,admin:valid&&!!u.is_admin,csrf:valid?req.session.csrf:null});});
app.post('/auth/register/request',async(req,res)=>{const {username,password,email,birthDate,confirmPassword,acceptTerms,acceptPrivacy}=req.body||{};const e=typeof email==='string'?email.trim().toLowerCase():'';if(!validName(username)||!validPassword(password)||password!==confirmPassword||!validEmail(e)||!validBirth(birthDate)||acceptTerms!==true||acceptPrivacy!==true)return res.status(400).json({error:'Vui lòng kiểm tra thông tin, mật khẩu xác nhận và điều khoản.'});if(getByName.get(username)||db.prepare('SELECT id FROM users WHERE email=?').get(e))return res.status(409).json({error:'Tên tài khoản hoặc email đã được sử dụng.'});try{await sendCode(e,'register',username,password,birthDate);res.json({ok:true,message:'Đã gửi mã xác thực đến email. Mã có hiệu lực 10 phút.'});}catch(err){res.status(503).json({error:err.message});}});
app.post('/auth/register/verify',(req,res)=>{const e=String(req.body?.email||'').trim().toLowerCase(),code=req.body?.code;const row=verifyCode(e,'register',code);if(!row)return res.status(400).json({error:'Mã sai, hết hạn hoặc vượt số lần thử.'});try{const result=db.prepare('INSERT INTO users(username,password_hash,salt,email,birth_date) VALUES(?,?,?,?,?)').run(row.username,row.password_hash,row.salt,e,row.birth_date);db.prepare('DELETE FROM verification_codes WHERE email=? AND purpose=?').run(e,'register');logIn(req,res,getUser.get(result.lastInsertRowid));}catch{res.status(409).json({error:'Tên tài khoản hoặc email đã được sử dụng.'});}});
app.post('/auth/password/request',async(req,res)=>{const e=String(req.body?.email||'').trim().toLowerCase();if(!validEmail(e))return res.status(400).json({error:'Email không hợp lệ'});const user=db.prepare('SELECT id FROM users WHERE email=?').get(e);if(user){try{await sendCode(e,'reset');}catch(err){return res.status(503).json({error:err.message});}}res.json({ok:true,message:'Nếu email đã đăng ký, mã khôi phục sẽ được gửi đến hộp thư.'});});
app.post('/auth/password/reset',(req,res)=>{const e=String(req.body?.email||'').trim().toLowerCase(),{code,password,confirmPassword}=req.body||{};if(!validPassword(password)||password!==confirmPassword)return res.status(400).json({error:'Mật khẩu phải từ 10–128 ký tự và trùng với xác nhận.'});const row=verifyCode(e,'reset',code);if(!row)return res.status(400).json({error:'Mã sai hoặc đã hết hạn.'});const salt=crypto.randomBytes(24).toString('hex');const result=db.prepare('UPDATE users SET password_hash=?,salt=? WHERE email=?').run(hashPassword(password,salt),salt,e);if(!result.changes)return res.status(400).json({error:'Không tìm thấy tài khoản.'});db.prepare('DELETE FROM verification_codes WHERE email=? AND purpose=?').run(e,'reset');res.json({ok:true,message:'Đã đổi mật khẩu. Vui lòng đăng nhập.'});});
app.post('/auth/login',(req,res)=>{const {username,password}=req.body||{};if(!validName(username)||typeof password!=='string'||password.length>128)return res.status(401).json({error:'Tài khoản hoặc mật khẩu không đúng'});const u=getByName.get(username);const dummySalt='000000000000000000000000000000000000000000000000';const hash=hashPassword(password,u?.salt||dummySalt);const expected=Buffer.from(u?.password_hash||'0'.repeat(128),'hex');if(!u||u.is_locked||!crypto.timingSafeEqual(Buffer.from(hash,'hex'),expected))return res.status(401).json({error:'Tài khoản hoặc mật khẩu không đúng, hoặc tài khoản đã bị khóa'});logIn(req,res,u);});
app.post('/auth/logout',(req,res)=>{if(!req.session.user||req.session.csrf!==req.get('x-csrf-token'))return res.sendStatus(403);req.session.destroy(()=>{req.clearSession();res.json({ok:true});});});
const requireAdmin=(req,res,next)=>{if(!buibaoahihi(req))return res.status(403).json({error:'Chỉ admin mới được phép'});if(req.get('x-csrf-token')!==req.session.csrf)return res.status(403).json({error:'CSRF không hợp lệ'});next();};
app.get('/api/admin/users',requireAdmin,(req,res)=>res.json(db.prepare('SELECT id,username,is_admin,is_locked,created_at FROM users ORDER BY id DESC').all()));
app.patch('/api/admin/users/:id',requireAdmin,(req,res)=>{const id=Number(req.params.id),target=getUser.get(id);if(!target)return res.sendStatus(404);const {locked}=req.body||{};if(typeof locked!=='boolean')return res.status(400).json({error:'Trạng thái không hợp lệ'});if(id===req.session.user.id)return res.status(400).json({error:'Không thể tự khóa tài khoản'});db.prepare('UPDATE users SET is_locked=? WHERE id=?').run(locked?1:0,id);res.json({ok:true});});
const contentCache=new Map();
const invalidateContent=()=>contentCache.clear();
app.get('/api/content',(req,res)=>{const type=req.query.type;if(!['rules','news','media'].includes(type)) return res.status(400).json({error:'Invalid type'});const hit=contentCache.get(type);if(hit&&hit.expires>Date.now()) return res.json(hit.items);const items=db.prepare('SELECT id,type,title,body,category,youtube_id,image_url,created_at FROM content WHERE type=? ORDER BY id DESC').all(type);contentCache.set(type,{items,expires:Date.now()+5000});res.json(items);});
function youtubeId(raw){if(!raw)return '';try{const u=new URL(raw);let id='';if(['youtu.be','www.youtu.be'].includes(u.hostname))id=u.pathname.slice(1).split('/')[0];else if(['youtube.com','www.youtube.com','m.youtube.com','music.youtube.com','youtube-nocookie.com','www.youtube-nocookie.com'].includes(u.hostname)){id=['/shorts/','/embed/','/live/','/v/'].some(prefix=>u.pathname.startsWith(prefix))?u.pathname.split('/')[2]:u.searchParams.get('v');}return /^[a-zA-Z0-9_-]{11}$/.test(id||'')?id:'';}catch{return '';}}
function saveImage(dataUrl){if(!dataUrl)return '';if(typeof dataUrl!=='string'||dataUrl.length>3*1024*1024)throw Error('Ảnh tối đa 2 MB sau khi tối ưu.');const m=dataUrl.match(/^data:image\/(png|jpeg|webp|gif);base64,([A-Za-z0-9+/=]+)$/);if(!m)throw Error('Chỉ hỗ trợ ảnh PNG, JPG, WEBP hoặc GIF.');const buf=Buffer.from(m[2],'base64');if(buf.length>2*1024*1024)throw Error('Ảnh tối đa 2 MB sau khi tối ưu.');const signatures={png:'89504e470d0a1a0a',jpeg:'ffd8ff',gif:'47494638',webp:'52494646'};if(!buf.subarray(0,signatures[m[1]].length/2).toString('hex').startsWith(signatures[m[1]]))throw Error('Tệp ảnh không hợp lệ.');const ext={jpeg:'jpg',png:'png',webp:'webp',gif:'gif'}[m[1]];const name=crypto.randomBytes(16).toString('hex')+'.'+ext;fs.writeFileSync(path.join(uploadDir,name),buf,{flag:'wx'});return '/uploads/'+name;}
function validate(input){const {type,title,body='',category='',url=''}=input||{};if(!['rules','news','media'].includes(type)||typeof title!=='string'||!title.trim()||title.length>140||typeof body!=='string'||body.length>10000||typeof category!=='string'||category.length>80||typeof url!=='string')return null;const id=type==='media'?youtubeId(url):'';if(type==='media'&&!id)return null;return {type,title:title.trim(),body:body.trim(),category:category.trim(),youtube_id:id};}
app.post('/api/content',requireAdmin,(req,res)=>{const x=validate(req.body);if(!x)return res.status(400).json({error:'Dữ liệu không hợp lệ. Media cần link YouTube hợp lệ.'});try{const imageUrl=x.type==='news'?saveImage(req.body.imageData||''):'';const info=db.prepare('INSERT INTO content(type,title,body,category,youtube_id,image_url) VALUES(?,?,?,?,?,?)').run(x.type,x.title,x.body,x.category,x.youtube_id,imageUrl);invalidateContent();res.status(201).json({id:info.lastInsertRowid});}catch(e){res.status(400).json({error:e.message||'Không thể lưu ảnh'});}});
app.put('/api/content/:id',requireAdmin,(req,res)=>{const x=validate(req.body);if(!x||!Number.isSafeInteger(Number(req.params.id))||Number(req.params.id)<1)return res.status(400).json({error:'Dữ liệu không hợp lệ'});const current=db.prepare('SELECT * FROM content WHERE id=?').get(Number(req.params.id));if(!current)return res.sendStatus(404);try{let imageUrl=current.image_url||'';if(x.type!=='news')imageUrl='';else if(req.body.removeImage===true)imageUrl='';else if(req.body.imageData)imageUrl=saveImage(req.body.imageData);const info=db.prepare('UPDATE content SET type=?,title=?,body=?,category=?,youtube_id=?,image_url=? WHERE id=?').run(x.type,x.title,x.body,x.category,x.youtube_id,imageUrl,Number(req.params.id));if(!info.changes)return res.sendStatus(404);invalidateContent();res.json({ok:true});}catch(e){res.status(400).json({error:e.message||'Không thể lưu ảnh'});}});
app.delete('/api/content/:id',requireAdmin,(req,res)=>{if(!Number.isSafeInteger(Number(req.params.id))||Number(req.params.id)<1)return res.status(400).json({error:'ID không hợp lệ'});const info=db.prepare('DELETE FROM content WHERE id=?').run(Number(req.params.id));if(!info.changes)return res.sendStatus(404);invalidateContent();res.json({ok:true});});
app.get('*',(req,res)=>res.sendFile(path.join(root,'public','index.html')));
const port=Number(process.env.PORT)||3000;
app.listen(port,()=>console.log(`NEXORA RP running at http://localhost:${port}`));
