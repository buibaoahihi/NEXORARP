# NEXORA RP – Optimized

Bản này giữ nguyên giao diện và chức năng chính, tập trung giảm tải tài nguyên hosting/trình duyệt.

## Đã tối ưu
- Giảm giới hạn JSON request từ 8 MB xuống 3 MB.
- Ảnh tin tức được nén phía trình duyệt sang WebP, giới hạn kích thước sau tối ưu.
- Cache HTTP 30 ngày cho `/uploads` và 1 ngày cho static assets khi chạy production.
- Thêm cache nội dung API 5 giây để giảm truy vấn SQLite khi nhiều người cùng mở trang.
- Chỉ tải video YouTube nền sau khoảng 1,8 giây; thiết bị bật Data Saver hoặc Reduce Motion sẽ không tải video nền.
- Logo được chuyển từ PNG lớn sang WebP nhẹ hơn.
- Giữ nguyên database schema, đăng nhập, OTP email, admin, tin tức, luật lệ và media YouTube.

## Cấu hình
Không đóng gói `.env` để tránh đưa thông tin SMTP/session secret vào file ZIP.
Trên hosting, giữ lại `.env` hiện tại của bạn hoặc khai báo các biến môi trường tương ứng.
